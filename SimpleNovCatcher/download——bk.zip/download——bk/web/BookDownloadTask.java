package download.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import download.dataPack.NovChapter;
import download.dataPack.NovInfo;
import tool.CharsetDectector;

public class BookDownloadTask implements Callable<Boolean>{
	protected String novSavePath=System.getProperty("user.dir")+File.separator+"autoUpdate";
	URL url;//小说的首页
	NovInfo info;
	PrintWriter localFileWriter;
	
	/**
	 * 
	 * @param url 小说的首页链接
	 * @throws IOException
	 */
	public BookDownloadTask(String url) throws IOException
	{
		this.url=new URL(url);
	}
	public BookDownloadTask(String url,String bookSavePath) throws IOException
	{
		this(url);
		this.novSavePath=bookSavePath+File.separator+"autoUpdate";
	}
	
	/**
	 * @return 是否读取了新章节
	 * @param url
	 * @param sinceIndexNum 从这一章开始下载
	 * @param line 从这一行开始写入
	 */
	public boolean multi_download_since(int sinceChapterIndex,long line)
	{
		int newReadChapterNum=0;
		
		try
		{
			//创建本地文件追加s写入流
			File file=new File(novSavePath+File.separator+info.getName()+".txt");
			file.getParentFile().mkdirs();//防止路径不存在
			
			if(file.exists()&&file.length()>0)
			{
				//读出前line行
				LinkedList<String> lines=new LinkedList<String>();
				BufferedReader reader=new BufferedReader(new FileReader(file));
				for(long nowLine=1;nowLine<=line;nowLine++) {
					lines.add(reader.readLine());
				}
				reader.close();

				file.delete();

				localFileWriter=new PrintWriter(new FileOutputStream(file,true ),true);

				//将前line行写回，（即将后面的行删除）
				for(long nowLine=1;nowLine<=line;nowLine++) {
					localFileWriter.println(lines.poll());
				}
				
			}else
			{
				//sinceChapterIndex=1;
				localFileWriter=new PrintWriter(new FileOutputStream(file,true),true);
				write(info);
			}
			
			LinkedList<URL> ChapterAddressList=HtmlDecoder.extractChapterList_Remote(url);
			 
			if(sinceChapterIndex>ChapterAddressList.size())throw new IndexOutOfBoundsException("指定的起始章节数不合法");
			
			ExecutorService pool=Executors.newFixedThreadPool(16);
			LinkedList<Future<NovChapter>> chapterList=new LinkedList<Future<NovChapter>>();
			
			//第几章节
			int index=1;
			
			for(URL aChapterLink:ChapterAddressList)
			{
				if(index<sinceChapterIndex)
				{
					index++;
					continue;
				}
				
				int i=(int)(Math.random()*100);////做一个随机延时，防止网站屏蔽
				Thread.sleep(i);
				
				newReadChapterNum++;
				
				ChapterDownloadTask task=new ChapterDownloadTask(aChapterLink);
				Future<NovChapter> future=pool.submit(task);
				chapterList.add(future);
				
				Future<NovChapter> f=chapterList.peek();
				if(f.isDone())
				{
	
System.out.println("name="+info.getName()+"；章节数"+index+"："+f.get().getTitle());
					write(f.get(),index);
					chapterList.remove();
					index++;
				}
			}
			
			while(chapterList.size()>0)
			{
				Future<NovChapter> future=chapterList.poll();
				write(future.get(),index);
//				chapterList.remove();
	
System.out.println("name="+info.getName()+"；章节数"+index+"："+future.get().getTitle());
				index++;
			}
			localFileWriter.close();
		}  catch (IOException e)
		{
			localFileWriter.close();
			e.printStackTrace();
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		} catch (ExecutionException e)
		{
			e.printStackTrace();
		}
		
		newReadChapterNum--;
	System.out.println(info.getName()+"###更新章节数="+newReadChapterNum);
		return true;
	}
	
	
	
	/**
	 * @param url
	 * @return boolean是否读取了新章节
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public boolean multi_download_since_last() throws MalformedURLException, IOException {
		//System.out.println(novSavePath+File.separator+info.getName()+".txt");
		long[] returnData=getLastLocalChapterIndexAndLine();
		int chapterNum=(int) returnData[0];
		long line=returnData[1];
		return multi_download_since( chapterNum,line-1);
		
	}
	
	protected void initInfo() throws IOException
	{
		info=HtmlDecoder.extractBookInfo(HtmlCatcher.getDoc(url.toString()));
	}
	protected long[] getLastLocalChapterIndexAndLine() throws IOException
	{
	
		File f=new File(novSavePath+File.separator+info.getName()+".txt");
		
		if(!f.exists())multi_download_since(0,0);
//-------------------------确定本地文件的最新章节数及相应文本行数------------------------------------
		String charset=CharsetDectector.getEncode(f);
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(f), charset));
		// 章节数
		int chapterNum = 0;
		long lineindex=0,tmp=0;
		
		String content = null;
		String regex="第[1-9][0-9]{0,3}章.*";
		// 创建标题匹配模式
		Pattern pattern = Pattern.compile(regex);
		
		while ((content = reader.readLine()) != null)
		{
			tmp++;
			
			boolean matchAny = false;
			Matcher matcher = pattern.matcher(content);
			matchAny =matcher.matches();

			if (content.length() > 0)
			{
				if (matchAny)// 是章节名
				{
					chapterNum++;
					lineindex=tmp;
				} else
				{
					continue;
				}
			}
		}
		reader.close();

		return new long[]{chapterNum,lineindex};
	}

	

	
	/**
	 * 将章节写入本地
	 * @param str
	 * @throws IOException 
	 */
	
	void write(NovInfo info) throws IOException
	{
		localFileWriter.println("书名："+info.getName());
		localFileWriter.println("作者："+info.getWritter());
		localFileWriter.println("最后更新："+info.getUpdateTime());
		localFileWriter.println("简介："+info.getIntroduction());
		localFileWriter.flush();
	}
	void write(NovChapter chapter,int index) throws IOException
	{
//System.out.println(chapter.getTitle());	
		localFileWriter.println();
		localFileWriter.print("第"+index+"章   ");
		localFileWriter.println(chapter.getTitle());
		localFileWriter.println();
		localFileWriter.println(chapter.getContent());
		localFileWriter.flush();
	}
	

	public Boolean call() throws IOException
	{
		initInfo();
		boolean isSuccess=multi_download_since_last();
		return isSuccess;
	}
}
